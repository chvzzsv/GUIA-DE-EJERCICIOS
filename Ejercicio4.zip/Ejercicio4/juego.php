<?php
class Juego{
    public $n;
    public $dinero;

    public function __construct($n, $dinero)
    {
        $this->n=$n;
        $this->dinero=$dinero;
    }

    public function jugar()
    {
        $p1 = 70; $p2 = 140; $p3 = 210; $p4 = 280; $p5 = 350;
        $p6 = 420; $p7 = 490; $p8 = 560; $p9 = 630; $p10 = 700;
        
        echo "Ha escogido el número ". $this->n;
        echo " equivalente al precio de $".$this->dinero. "<br>";

        if($this->n == 7)
        {
            echo "El número ganador es el 7";
            if($this->dinero == 7)
            {
                echo " Ha ganado $".$p7." Felicidades!!";
            }
        }
        else
        {
            echo "Lamentablemente no ha ganado.";
        }
    }
}
$jueguito = new Juego($_POST['numero'], $_POST['dinero']);
$jueguito->jugar();
?>