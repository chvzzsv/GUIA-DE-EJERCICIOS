<?php
class Temperatura{
    public $medidorG;

    public function __construct($medidorG)
    {
        $this->medidorG=$medidorG;
    }

    public function calcular()
    {
        if($this->medidorG <= 0)
        {
           echo "<font color='blue'>"."TEMPERATURA MÁXIMA FRIA ".$this->medidorG."°C";
        }
        else if($this->medidorG <= 30)
        {
            echo "<font color='yellow'>"."TEMPERATURA MÁXIMA ESTABLE ".$this->medidorG."°C";
        }
        else if($this->medidorG >= 31)
        {
            echo "<font color='red'>"."TEMPERATURA MÁXIMA CALIENTE ".$this->medidorG."°C";
        }
    }
}
$grados = new Temperatura(35);
$grados->calcular();

?>