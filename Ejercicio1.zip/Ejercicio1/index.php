<!-- Utilizando solamente código php y POO cree un código que permita calcular grados
centígrados en Fahrenheit -->
<?php
class Grados {

    /* Declaramos variables */
    public $fahrenheit;
    public $centigrados;

    /* Constructor */
    public function __construct($fahrenheit, $centigrados)
    {
        $this->fahrenheit=$fahrenheit;
        $this->centigrados=$centigrados;
       
    }

    /* Creamos una función  */
    public function calcular()
    {
        /* Hacemos la operación e imprimimos datos */
        $fahrenheit=$this->centigrados=(9 / 5)*$this->fahrenheit+32;
        $centigrados=$this->fahrenheit;
        echo $centigrados." grados °C es equivalente a: ".$fahrenheit. " grados °F";
    }
}
/* Creamos el objeto */
$calculo = new Grados(50, 0);
/* Mandamos a llamar el objeto y el método */
$calculo->calcular();
?>